<form method="post" action="inscriptionsuite.php" class="text-center">
  <fieldset>
    <legend class="text-light bg-info rounded shadow-lg">Inscription</legend>
      <p>
      <label for="pseudo" class="col-sm-2 col-form-label">Pseudo : </label><input name="pseudo" type="text" id="pseudo" class="col-sm-3 col-form-label form-control-lg"/>
      <label for="password" class="col-sm-2 col-form-label">Mot de Passe : </label><input type="password" name="password" id="password" class="col-sm-3 col-form-label form-control-lg"/>
      <label for="name" class="col-sm-2 col-form-label">Nom : </label><input type="text" name="name" id="name" class="col-sm-3 col-form-label form-control-lg"/>

    </p>
  </fieldset>
  <p><input type="submit" class="btn text-light text-center btn-info shadow-lg rounded" value="Connexion" /></p></form>
</form>
