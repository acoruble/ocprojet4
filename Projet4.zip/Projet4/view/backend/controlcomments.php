<?php ob_start();
?>
</br>
<div class="container">
  <div class="row mx-auto col-md-10 col-md-offset-2 table-responsive">
    <table class="table table-striped table-hover table-bordered">
      <thead>
        <tr>
          <th class="text-center">Pseudo</th>
          <th class="text-center">Date</th>
          <th class="text-center">Message</th>
          <th class="text-center">Nombre de report</th>
          <th class="text-center">Action</th>
        </tr>
      </thead>
        <?php foreach ($listComments as $comment): ?>
          <tr>
            <td class="text-center bg-info"><?= $comment->pseudo() ?></td>
            <td class="text-center"><?= $comment->date() ?></td>
            <td class="text-center  bg-info"><?= $comment->message() ?></td>
            <td class="text-center"><?= $comment->nbReport() ?></td>
            <td class="text-center bg-info">
              <a href="index.php?admin=deletecomment&id=<?= $comment->id() ?>" class="btn btn-light btn-xs">Supprimer</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </table>
  </div>
</div>

<?php
$content = ob_get_clean();

require('template.php');
