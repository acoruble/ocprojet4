<?php

require_once("Manager.php");

class UserManager extends Manager
{

  public function check($pseudo, $password)
  {
    $db = $this->dbConnect();
    $req = $db->prepare('SELECT password FROM admin WHERE pseudo = :pseudo');
    $req->execute(array('pseudo' => $pseudo));
    $resultat = $req->fetch();
    $isPasswordCorrect = password_verify($password, $resultat['password']);
    return $isPasswordCorrect;
  }

  public function connection($pseudo, $password)
  {
    $db = $this->dbConnect();
    $req = $db->prepare('SELECT id, name FROM admin WHERE pseudo = :pseudo');
    $req->execute(array('pseudo' => $pseudo));
    $resultat = $req->fetch();
    return $resultat;
  }

  public function logout()
  {
    session_destroy();
  }
}
